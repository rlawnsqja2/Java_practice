package zombie;
import java.util.*;
public class ZombieGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		Zombie zom1 = new Zombie("좀비1",7);
		Zombie zom2 = new Zombie("좀비2",15);
		
		Hero hero = new Hero("김준범",1,3);
		
		while(true) {
			System.out.println("왼쪽(1), 오른쪽(2), 점프(3)");
			int input = s.nextInt();
			if(input==1) hero.leftMove();
			else if(input==2) hero.rightMove();
			else if(input==3) hero.jump();
			
			zom1.move();
			zom2.move();
			
			if((hero.hero==zom1.zom)||(hero.hero==zom1.zom)) {
				hero.life--;
				if(hero.life==0) {
					System.out.println("생명이 0입니다. 게임을 종료합니다");
					break;
				}
				else {
				System.out.println("좀비에게 잡혔습니다. 현재 나의 생명은 "+hero.life+"개 남았습니다. 처음위치에서 다시 시작합니다.");
				hero.hero=1;
				}
			}
			//목적지에 도착한 경우
			if(hero.hero>=20) {
				System.out.println("게임을 클리어하였습니다. 게임을 종료합니다.");
				break;
			}
		}
	}

}