package car;

import java.util.Random;
import java.util.Scanner;

public class CarGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random r = new Random();
		Random r1 = new Random();

		Car car1 = new Car("김준범", 200, 20);

		Car car2 = new Car("컴퓨터", 200, 20);

		System.out.println("자동차 게임을 시작합니다.");

		int count = 0;
		while (car1.km < 5000) {
			System.out.println("엑셀(1), 감속(2), 정지(3), 주행거리표시(4)");
			int input = s.nextInt();
			int f = r.nextInt(10)+1;
			if(f==1)
				car1.speed = 0;
			
			if (input == 1) {
				car1.speedUp();
				count++;
			} else if (input == 2) {
				car1.speedDown();
				count++;
			} else if (input == 3) {
				car1.stop();
				count++;
			} else if (input == 4)
				car1.printKm();
		}
		System.out.println("트랩 한바퀴 돌았을 때 " + count + "번 밟았습니다.");

		int comcount = 0;
		while (car2.km < 5000) {
			int comput = r.nextInt(4) + 1;
			int f = r1.nextInt(10)+1;
			if(f==1)
				car2.speed = 0;
			if (comput == 1) {
				car2.speedUp();
				comcount++;
			} else if (comput == 2) {
				car2.speedDown();
				comcount++;
			} else if (comput == 3) {
				car2.stop();
				comcount++;
			} else if (comput == 4)
				car2.printKm();
		}
		System.out.println("컴퓨터가 트랩 한바퀴 돌았을 때 " + comcount + "번 밟았습니다.");

		if (count < comcount) {
			System.out.println("컴퓨터와 경주해서 내가 먼저 들어왔습니다.");
		} else if (count > comcount) {
			System.out.println("컴퓨터와 경주해서 내가 나중에 들어왔습니다.");
		} else
			System.out.println("컴퓨터와 동시에 들어왔습니다.");

	}

}
