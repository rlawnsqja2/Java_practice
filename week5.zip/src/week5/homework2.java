package week5;

import java.util.Random;
import java.util.Scanner;

public class homework2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random r = new Random();
		int mywin = 0, comwin = 0;
		for (int i = 1; i <= 5; i++) {
			System.out.println("가위(1), 바위(2), 보(3)을 입력하시오");
			int user = s.nextInt();
			int computer = r.nextInt(3) + 1;

			if ((mywin < 2) || (comwin < 2))
				if ((user == 1) && (computer == 1))
					System.out.println("나 : 가위 컴퓨터 : 가위 비겼습니다.");
				else if ((user == 1) && (computer == 2)) {
					System.out.println("나 : 가위 컴퓨터 : 바위 졌습니다.");
					comwin++;
				} else if ((user == 1) && (computer == 3)) {
					System.out.println("나 : 가위 컴퓨터 : 보 이겼습니다.");
					mywin++;
				} else if ((user == 2) && (computer == 1)) {
					System.out.println("나 : 바위 컴퓨터 : 가위 이겼습니다.");
					mywin++;
				} else if ((user == 2) && (computer == 2)) {
					System.out.println("나 : 바위 컴퓨터 : 바위 비겼습니다.");
				} else if ((user == 2) && (computer == 3)) {
					System.out.println("나 : 바위 컴퓨터 : 보 졌습니다.");
					comwin++;
				} else if ((user == 3) && (computer == 1)) {
					System.out.println("나 : 보 컴퓨터 : 가위 졌습니다.");
					comwin++;
				} else if ((user == 3) && (computer == 2)) {
					System.out.println("나 : 보 컴퓨터 : 바위 이겼습니다.");
					mywin++;
				} else if ((user == 3) && (computer == 3))
					System.out.println("나 : 보 컴퓨터 : 보 비겼습니다.");
				else if (user == 4) {
					System.out.println("가위바위보 게임을 중지합니다.");
					break;
				}

		}
		if (mywin > comwin)
			System.out.println("5판 3선승제 가위바위보 내가 이겼습니다.");
		else if (mywin < comwin)
			System.out.println("5판 3선승제 가위바위보 컴퓨터가 이겼습니다.");
		else
			System.out.println("5판3선승제 가위바위보 비겼습니다.");
	}

}
