package week5;

import java.util.Random;
import java.util.Scanner;

public class homework4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random r = new Random();
		Random z = new Random();

		int zombie1 = 7, zombie2 = 15; // 좀비들의 좌표값
		int cha = 1; // 나의 좌표값
		System.out.println("좀비게임 스타트");
		while (true) {

			System.out.println("왼쪽(1), 오른쪽(2), 점프(3), 종료(4)");
			int ch = s.nextInt();
			if (ch == 1) {
				cha--;
				if (cha <= 0)
					cha = 1;
				System.out.println("왼족으로 움직였습니다.");
			} else if (ch == 2) {
				cha++;
				System.out.println("오른쪽으로 움직였습니다.");
			} else if (ch == 3) {
				int jump = r.nextInt(3) + 1;
				cha += jump;
				System.out.println("점프하였습니다.");
			} else if (ch == 4) {
				System.out.println("게임을 종료합니다. ");
				break;
			}
			// 좀비의 움직임
			zombie1 = zombie1 + z.nextInt(3) - 1;
			zombie2 = zombie2 + z.nextInt(3) - 1;
			if (zombie1 > 20)
				zombie1 = 20;
			else if (zombie1 < 1)
				zombie1 = 1;
			if (zombie2 > 20)
				zombie2 = 20;
			else if (zombie2 < 1)
				zombie2 = 1;
			// 좀비한테 잡힘
			if ((cha == zombie1) || (cha == zombie2)) {
				System.out.println("좀비한테 잡혔습니다. 처음위치에서 다시 시작합니다.");
				cha = 1;
			}
			// 도착
			else if (cha >= 20) {
				System.out.println("미션 클리어!!! 목적지에 도착했습니다.");
				break;
			}
			// 현재 위치
			System.out.println("현재 나의 위치 " + cha + " 현재 좀비1의 위치 " + zombie1 + " 현재 좀비2의 위치 " + zombie2);
		}
	}

}
