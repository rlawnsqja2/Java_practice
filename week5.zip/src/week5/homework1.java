package week5;

import java.util.*;

public class homework1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int sum = 0;
		for (int i = 1; i <= 100; i++) {
			sum = sum + i;
		}
		System.out.println("1~100까지 합은 " + sum); // 1-1

		int ran = r.nextInt(100) + 1;

		int ran1 = r.nextInt(100) + 1;
		while (ran == ran1) {
			ran1 = r.nextInt(100) + 1;
		}
		int ran2 = r.nextInt(100) + 1;
		while ((ran2 == ran1) || (ran2 == ran)) {
			ran2 = r.nextInt(100) + 1;
		}
		System.out.println("뽑힌 숫자는 " + ran + "," + ran1 + "," + ran2); // 1-2

		int lotto = r.nextInt(45) + 1;
		int lotto1 = r.nextInt(45) + 1;
		while (lotto1 == lotto) {
			lotto1 = r.nextInt(45) + 1;
		}
		int lotto2 = r.nextInt(45) + 1;
		while ((lotto2 == lotto)||(lotto2==lotto1)) {
			lotto2 = r.nextInt(45) + 1;
		}
		int lotto3 = r.nextInt(45) + 1;
		while ((lotto3 == lotto)||(lotto3 == lotto1)||(lotto3==lotto2)) {
			lotto3 = r.nextInt(45) + 1;
		}
		int lotto4 = r.nextInt(45) + 1;
		while ((lotto4 == lotto)||(lotto4 == lotto1)||(lotto4 == lotto2)||(lotto4==lotto3)) {
			lotto4 = r.nextInt(45) + 1;
		}
		int lotto5 = r.nextInt(45) + 1;
		while ((lotto5 == lotto)||(lotto5 ==lotto1)||(lotto5 ==lotto2)||(lotto5==lotto3)||(lotto5==lotto4)) {
			lotto5 = r.nextInt(45) + 1;
		}
		System.out.println("로또 추첨 결과 "+lotto+" "+lotto1+" " +lotto2+" " +lotto3+" " +lotto4+" " +lotto5);
	}

}
