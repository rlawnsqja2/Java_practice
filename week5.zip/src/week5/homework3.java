package week5;

import java.util.Random;
import java.util.Scanner;

public class homework3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random r = new Random();
		Random d = new Random();

		int wizhp = 10;
		int warhp = 20;

		while (true) {
			System.out.println("공격하려면 1을 누르세요.");
			int atk = s.nextInt();

			if (atk == 1) {
				int a = r.nextInt(11) + 15; // 15-25 0-10
				int b = d.nextInt(11) + 5;

				int wizhp1 = wizhp - b;
				int warhp1 = warhp - a;

				if ((wizhp1 > 0) && (warhp1 > 0))
					System.out.println("내 마법사의 체력 : " + wizhp1 + " 적 전사의 체력 : " + warhp1 + "입니다.");
				else if ((wizhp1 <= 0) && (warhp1 > 0)) {
					System.out.println("마법사가 죽었습니다");
					break;
				} else if ((warhp1 <= 0) && (wizhp1 > 0)) {
					System.out.println("전사가 죽었습니다.");
					break;
				} else if ((warhp1 <= 0) && (wizhp1 <= 0)) {
					System.out.println("마법사와 전사 모두 죽었습니다.");
					break;
				}
			} else {
				System.out.println("게임을 종료합니다");
				break;
			}
		}
	}

}
