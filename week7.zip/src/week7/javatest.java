package week7;
import java.util.*;
public class javatest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1번문제
		System.out.println("1번문제");
		Scanner s = new Scanner(System.in);
		
		System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
		int Goal = s.nextInt();
		if(Goal==1) {
			System.out.println("왼쪽으로 공을 찼습니다.");
		}
		else if(Goal==2) {
			System.out.println("가운데로 공을 찼습니다.");
		}
		else if(Goal==3) {
			System.out.println("오른쪽으로 공을 찼습니다.");
		}
		System.out.println("골인입니다.");
		if(Goal==4)
			System.out.println("게임을 종료합니다.");
		
		
		
		//2번문제
		System.out.println("2번문제");
		Random r = new Random();
		System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
		int goal2 = s.nextInt();
		
		if(goal2==1) {
			System.out.println("왼쪽으로 공을 찼습니다.");
			int keeper =r.nextInt(3)+1;
			if(goal2==keeper) {
				System.out.println("아깝습니다.!!! 골키퍼가 골을 막았습니다.");
			}
			else
				System.out.println("골인입니다.");
		}
		else if(goal2==2) {
			System.out.println("가운데로 공을 찼습니다.");
			int keeper =r.nextInt(3)+1;
			if(goal2==keeper) {
				System.out.println("아깝습니다.!!! 골키퍼가 골을 막았습니다.");
			}
			else
				System.out.println("골인입니다.");
		}
		else if(goal2==3) {
			System.out.println("오른쪽으로 공을 찼습니다.");
			int keeper =r.nextInt(3)+1;
			if(goal2==keeper) {
				System.out.println("아깝습니다.!!! 골키퍼가 골을 막았습니다.");
			}
			else
				System.out.println("골인입니다.");
		}
		else if(goal2==4)
			System.out.println("게임을 종료합니다.");
		
		
		//3번문제
		System.out.println("3번문제");
		System.out.println("내가 공을 찰 차례입니다.(키커)");
		System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
		int usegoal = s.nextInt();
		int comkeep = r.nextInt(3)+1;
		
		if(usegoal==comkeep) {
			System.out.println("아깝습니다.!!! 골키퍼가 골을 막았습니다.");
		}
		else if(usegoal!=comkeep) {
			System.out.println("골인입니다.");
		}
		
		if(usegoal==4)
			System.out.println("게임을 종료합니다.");
		
		System.out.println("내가 공을 막을 차례입니다.(골키퍼)");
		System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
		int usekeep = s.nextInt();
		int comgoal = r.nextInt(3)+1;
		
		if(usekeep==comgoal) {
			System.out.println("내가 컴퓨터의 골을 막았습니다.");
		}
		else if(usekeep!=comgoal) {
			System.out.println("컴퓨터의 골을 막지 못했습니다.");
		}
		
		if(usekeep==4)
			System.out.println("게임을 종료합니다.");
		
		
		//4번문제
		System.out.println("4번문제");
		int usecount=0,comcount=0;//골 횟수
		
		for(int i=1;i>=0;i++) {
			System.out.println("내가 공을 찰 차례입니다.(키커)");
			System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
			int usegoal1 = s.nextInt();
			int comkeep1 = r.nextInt(3)+1;
			
			
			
			if(usegoal1==comkeep1) {
				System.out.println("아깝습니다.!!! 골키퍼가 골을 막았습니다.");
			}
			else if(usegoal1!=comkeep1) {
				System.out.println("골인입니다.");
				usecount++;
			}
			
			if(usegoal1==4)
				System.out.println("게임을 종료합니다.");
			
			System.out.println("내가 공을 막을 차례입니다.(골키퍼)");
			System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
			int usekeep1 = s.nextInt();
			int comgoal1 = r.nextInt(3)+1;
			
			if(usekeep1==comgoal1) {
				System.out.println("내가 컴퓨터의 골을 막았습니다.");
			}
			else if(usekeep1!=comgoal1) {
				System.out.println("컴퓨터의 골을 막지 못했습니다.");
				comcount++;
			}
			
			if(usekeep1==4) {
				System.out.println("게임을 종료합니다.");
				break;
			}		
			if(i>=5) {
				if(usecount>comcount) {
					System.out.println("나는 "+usecount+"골, 컴퓨터는 "+comcount+"골을 넣어 내가 이겼습니다.");
					System.out.println("게임을 종료합니다.");
					break;
				}
				else if(usecount<comcount) {
					System.out.println("나는 "+usecount+"골, 컴퓨터는 "+comcount+"골을 넣어 내가 졌습니다.");
					System.out.println("게임을 종료합니다.");
					break;
				}
				else {
					System.out.println("나는 "+usecount+"골, 컴퓨터는 "+comcount+"골을 넣어 비겼습니다.");
					System.out.println("게임을 종료합니다.");
					break;
				}
			}
		}
		
		
		//5번문제
		System.out.println("5번문제");
		int usecount1=0,comcount1=0;//골 횟수
				
				for(int i=1;i>=0;i++) {
					System.out.println("내가 공을 찰 차례입니다.(키커)");
					System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
					int usegoal1 = s.nextInt();
					int comkeep1 = r.nextInt(3)+1;
					
					
					
					if(usegoal1==comkeep1) {
						System.out.println("아깝습니다.!!! 골키퍼가 골을 막았습니다.");
					}
					else if(usegoal1!=comkeep1) {
						System.out.println("골인입니다.");
						usecount1++;
					}
					
					if(usegoal1==4)
						System.out.println("게임을 종료합니다.");
					
					System.out.println("내가 공을 막을 차례입니다.(골키퍼)");
					System.out.println("왼쪽(1),가운데(2),오른쪽(3),게임 끝(4)");
					int usekeep1 = s.nextInt();
					int comgoal1 = r.nextInt(3)+1;
					
					if(usekeep1==comgoal1) {
						System.out.println("내가 컴퓨터의 골을 막았습니다.");
					}
					else if(usekeep1!=comgoal1) {
						System.out.println("컴퓨터의 골을 막지 못했습니다.");
						comcount1++;
					}
					
					if(usekeep1==4) {
						System.out.println("게임을 종료합니다.");
						break;
					}		
					if(i>=5) {
						if(usecount1>comcount1) {
							System.out.println("나는 "+usecount1+"골, 컴퓨터는 "+comcount1+"골을 넣어 내가 이겼습니다.");
							System.out.println("게임을 종료합니다.");
							break;
						}
						else if(usecount1<comcount1) {
							System.out.println("나는 "+usecount1+"골, 컴퓨터는 "+comcount1+"골을 넣어 내가 졌습니다.");
							System.out.println("게임을 종료합니다.");
							break;
						}
						else {
							System.out.println("나는 "+usecount1+"골, 컴퓨터는 "+comcount1+"골을 넣어 승부가 나지 않았습니다.");
							System.out.println("게임을 지속합니다.");
						}
					}
				}

	}

}
