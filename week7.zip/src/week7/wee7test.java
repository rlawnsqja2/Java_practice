package week7;
import java.util.*;
public class wee7test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Random r = new Random();
		int a = r.nextInt(6)+1;
		
		String name1 = "조강홍"; 
		String name2 = "조강홍";
		int num = 0;
		
		char n1 = name1.charAt(1);
		int len = name1.length();
		
		String old = "자바 프로그래밍";
		String ne = old.replace("자바", "JAVA");
		
		String sub = old.substring(3);
		String board = "번호,제목,내용,글쓴이";
		String si[] = board.split(",");
		
		int data[] = new int[10];
		
		data[0] = 1;
		data[1] = 10;
		data[9] = 100;
		
		int map[] = {1,2,3,4,5,6,7,8,9,0};
		
		for(int i = 0; i < data.length; i++) {
			System.out.println(data[i]);
		}
		
		if(name1.equals(name2)) {
			
		}
	}

}
