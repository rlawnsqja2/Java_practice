
public class ButtonEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Button btn = new Button();
		
		class OkListener implements Button.ClickListener{
			public void onClick() {
				System.out.println("버튼이 눌렸습니다.");
			}
			
		}
		
		
		btn.setClickListener(new OkListener());
		btn.click();
	}

}

class Button {
	
	public static interface ClickListener {
		void onClick(); //추상메소드
	}
	
	private ClickListener click;
	
	public void setClickListener(ClickListener click) {
		this.click = click;
	}
	
	public void click() {
		this.click.onClick();
	}
}