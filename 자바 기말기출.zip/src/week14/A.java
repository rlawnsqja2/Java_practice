package week14;

public class A {
	
	String field = "A-Field";
	
	int pos;
	
	class B {
		String field = "B-Field";
		int field1 = 1;
		static int field2 = 2;
		
		public B() {
			//pos = 10;
		}
		
		public void method1() {
			
		}
		
		void print() {
			System.out.println(this.field+"출력");
			System.out.println(A.this.field+"A클래스 출력");
		}
	}
	
	public void useB() {
		B b = new B();
		b.field1 = 1;
		b.method1();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A.B ab = new A.B();
	}

}
