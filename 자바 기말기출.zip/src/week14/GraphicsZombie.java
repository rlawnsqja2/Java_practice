import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;

public class GraphicsZombie {
	
	final int MOVE_STEP = 5;			// 좀비가 한번에 움직이는 스텝
	final int MAX_X = 400;				// 맵의 가로 크기
	final int MAX_Y = 300;				// 맵의 세로 크기
	
	int x;										// 좀비의 x 좌표 값
	int y;										// 좀비의 y 좌표 값
	int dir;									// 방향 왼쪽 오른쪽
	int imgWidth = 20;						// 좀비 이미지 가로 크기
	int imgHeight = 20;						// 좀비 이미지 세로 크기
	int count;
	boolean toggle;
	Random r = new Random();
	ImageIcon batImgIcon[] = new ImageIcon[2];
	Image img[] = new Image[2];
	
	public GraphicsZombie(int x, int y) {
		this.x = x;
		this.y = y;
		for(int i=0; i<2; i++) {
			batImgIcon[i] = new ImageIcon("images/enemy"+(i+1)+".png");
			img[i] = batImgIcon[i].getImage();
		}
	}
	
	public void moveLeft() {
		x = x - MOVE_STEP;
		if(x < 0) x = 0;
	}
	
	public void moveRight() {
		x = x + MOVE_STEP;
		if(x > MAX_X - imgWidth) x = MAX_X - imgWidth;
	}
	
	public void moveUp() {
		y = y - MOVE_STEP;
		if(y < 0) y = 0; 
	}
	
	public void moveDown() {
		y = y + MOVE_STEP;
		if(y > MAX_Y - imgHeight) y = MAX_X - imgHeight;
	}
	
	// 좀비가 랜덤하게 움직임
	public void randomMove() {
		
		dir = r.nextInt(3);		
		
		if(dir==0);
		else if(dir==1) moveLeft();
		else if(dir==2) moveRight();

		toggle = !toggle;
	}
	
	//적과 충돌 체크하는 메소드
	public boolean crush(GraphicsHero zombie) {
		if(((zombie.x < x) && (x < zombie.x+zombie.imgWidth))&&
		((zombie.y < y) && (y < zombie.y+zombie.imgHeight)))
			return true;
		if(((zombie.x < x+imgWidth) && (x+imgWidth < zombie.x+zombie.imgWidth))&&
				((zombie.y < y) && (y < zombie.y+zombie.imgHeight)))
					return true;
		if(((zombie.x < x) && (x < zombie.x+zombie.imgWidth))&&
				((zombie.y < y+imgHeight) && (y+imgHeight < zombie.y+zombie.imgHeight)))
					return true;
		if(((zombie.x < x+imgWidth) && (x+imgWidth < zombie.x+zombie.imgWidth))&&
				((zombie.y < y+imgHeight) && (y+imgHeight < zombie.y+zombie.imgHeight)))
					return true;
		return false;
	}

	// 좀비를 그려주는 메소드 - 좀비 2개의 이미지를 매번 바꿔서 그려줌
	public void paint(Graphics g) {
		
		if(toggle)
			g.drawImage(img[0], x, y, null);
		else
			g.drawImage(img[1], x, y, null);
		
	}
}
