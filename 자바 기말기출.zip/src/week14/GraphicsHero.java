import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class GraphicsHero {
	
	final int MOVE_STEP = 10;			// 히어로가 움직이는 간격
	final int MAX_X = 400;				// 맵의 가로크기
	final int MAX_Y = 300;				// 맵의 세로크기
	
	int x;										// 주인공 X 위치
	int y;										// 주인공 Y 위치
	int dir;									// 주인공 방향 상태
	ImageIcon heroImgIcon[] = new ImageIcon[6];	// 주인공 이미지 아이콘
	Image img[] = new Image[6];					// 주인공 이미지
	
	int imgWidth = 21;						// 주인공 이미지 가로 크기
	int imgHeight = 26;						// 주인공 이미지 세로 크기
	boolean jump;							// 주인공이 점프하는 상태인지 표시
	int jumpCount = 1;						// 주인공이 점프할 경우 점프 단계

	int count;
	
	public GraphicsHero(int x, int y) {
		this.x = x;
		this.y = y;
		for(int i=0; i<6; i++) {
			heroImgIcon[i] = new ImageIcon("images/hero0"+(i+1)+".png");
			img[i] = heroImgIcon[i].getImage();
		}
	}
	
	public void moveLeft() {
		x = x - MOVE_STEP;
		if(x < 0) x = 0;
	}
	
	public void moveRight() {
		x = x + MOVE_STEP;
		if(x > MAX_X - imgWidth) x = MAX_X - imgWidth;
	}
	
	public boolean crush(GraphicsZombie zombie) {
		if(((zombie.x < x) && (x < zombie.x+zombie.imgWidth))&&
		((zombie.y < y) && (y < zombie.y+zombie.imgHeight)))
			return true;
		if(((zombie.x < x+imgWidth) && (x+imgWidth < zombie.x+zombie.imgWidth))&&
				((zombie.y < y) && (y < zombie.y+zombie.imgHeight)))
					return true;
		if(((zombie.x < x) && (x < zombie.x+zombie.imgWidth))&&
				((zombie.y < y+imgHeight) && (y+imgHeight < zombie.y+zombie.imgHeight)))
					return true;
		if(((zombie.x < x+imgWidth) && (x+imgWidth < zombie.x+zombie.imgWidth))&&
				((zombie.y < y+imgHeight) && (y+imgHeight < zombie.y+zombie.imgHeight)))
					return true;
		
		return false;
	}
	
	public boolean heroUpdate() {
		count++;
		
		if(jump==true) {
			if(jumpCount <= 5) y = y - 10;
			else if (jumpCount <= 10) y = y + 10;
			if(jumpCount==10) {
				jump = false;
				jumpCount = 1;
			}
			else jumpCount++;
		}
		// 주인공이 맵의 크기를 넘어갈 경우 목적지 도달 게임 종료
		if(x >= MAX_X-imgWidth) return true;
		else return false;
	}
	// 주인공을 그려주는 메소드
	public void paint(Graphics g) {
		// 주인공의 dir이 1 이면 오른쪽, 2이면 왼쪽 이미지
		// jump 가 true 이면 점프 상태 이미지
		if(dir == 1) {
			if(jump == true)
				g.drawImage(img[2], x, y, null);
			else 
				g.drawImage(img[count%2], x, y, null);
		}
		else if(dir == 2) {
			if(jump == true)
				g.drawImage(img[5], x, y, null);
			else
				g.drawImage(img[count%2+3], x, y, null);
		}
	}
}
