package zombie;
import java.util.*;
public class zombieGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		zombie zom1 = new zombie("좀비1",7);
		zombie zom2 = new zombie("좀비2",15);
		
		Hero hero = new Hero("김준범",1,3);
		
		while(true) {
			System.out.println("왼쪽(1), 오른쪽(2), 점프(3)");
			int input = s.nextInt();
			if(input==1) hero.leftMove();
			else if(input==2) hero.rightMove();
			else if(input==3) hero.jump();
			
			zom1.move();
			zom2.move();
			
			if((hero.hero==zom1.zom)||(hero.hero==zom1.zom)) {
				hero.life--;
				System.out.println("좀비와 부딪혔습니다.");
				hero.hero=1;
			}
			if(hero.hero>=20) {
				break;
			}
		}
	}

}
