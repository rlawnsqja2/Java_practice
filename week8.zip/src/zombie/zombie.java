package zombie;

import java.util.*;

public class zombie {
	Random r = new Random();

	String name;
	int zom; // 현재 위치

	public zombie(String n, int z) {
		name = n;
		zom = z;
	}

	public void move() {
		zom = zom + r.nextInt(3)-1;
		if (zom > 20) {
			zom = 20;
		} else if (zom < 1) {
			zom = 1;
		}
		System.out.println(name + "의 현재 위치는" + zom + "입니다.");
	}
}
