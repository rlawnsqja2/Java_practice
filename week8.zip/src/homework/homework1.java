package homework;

public class homework1 {
	
	//객체의 속성 = 클래스 멤버변수
	String name; //강아지 이름
	int age; //강아지 나이
	
	public homework1(String n, int a) {
		name = n;
		age = a;
	}
	
	//객체의 동작(행동) = 클래스의 메소드
	public void bark() {
		System.out.println(name+"이(가) 멍멍하고 짖었습니다.");
	}
	
	public void bite(String n) {
		System.out.println(name+"이(가) "+n+"을 물었습니다.");
	}
}
