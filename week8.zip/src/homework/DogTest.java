package homework;

public class DogTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		homework1 d1 = new homework1("고로",5);
		
		
		d1.bark();
		d1.bite("도둑");
		
		homework1 d2 = new homework1("히나",10);

		d2.bite("사람");
	}

}
