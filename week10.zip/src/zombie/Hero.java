package zombie;
import java.util.*;
public class Hero {
	Random r = new Random();
	
	String name;
	int hero;
	int life;
	
	public Hero(String name, int hero, int life) {
		this.name = name;
		this.hero = hero;
		this.life=life;
	}
	
	public void leftMove() {
		hero = hero -1;
		if(hero<1) hero = 1;
		System.out.println(name+"이 왼쪽으로 이동하여 현재 위치는 "+hero+"입니다.");
	}
	
	public void rightMove() {
		hero = hero +1;
		if(hero>20) hero = 20;
		System.out.println(name+"이 오른쪽으로 이동하여 현재 위치는 "+hero+"입니다.");
	}
	
	public void jump() {
		int j = r.nextInt(3)+1;
		hero = hero + j;
		if (hero > 20) {
			hero = 20;
		} else if (hero < 1) {
			hero = 1;
		}
		System.out.println("주인공이 "+j+"만큼 점프하였습니다. 현재 위치는 "+hero+"입니다.");
	}
}
