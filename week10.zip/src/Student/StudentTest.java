package Student;
import java.util.*;
public class StudentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st1 = new Student("최철민");
		Student st2 = new Student("은지담", 1575);
		Student st3 = new Student("김민결", 1567, "인공과");
		
		st1.study(5);
		double gr =  st1.showGrade();
		
	}

}
