package Grade;
import java.util.*;
public class Student {
	Scanner s = new Scanner(System.in);
	
	String name;
	int kor; //국어
	int eng; //영어	
	int mat; //수학	
	double avg;
	
	public Student(String name, int kor,int eng, int mat) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
	}
	public void avg() {
		avg = (kor+eng+mat)/3.0;
	}
	
	public void grade() {
		if (avg>90) System.out.println(name+"의 등급은 A 입니다. 평균은 "+avg);
		else if (avg>80) System.out.println(name+"의 등급은 B 입니다. 평균은 "+avg);
		else if (avg>70) System.out.println(name+"의 등급은 C 입니다. 평균은 "+avg);
		else if (avg>60) System.out.println(name+"의 등급은 D 입니다. 평균은 "+avg);
		else System.out.println(name+"의 등급은 F 입니다. 평균은 "+avg);
	}
}
