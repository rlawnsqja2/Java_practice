package Grade;
import java.util.*;
public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		System.out.println("학생수를 입력하세요");
		int Student = s.nextInt();
		
		Student stu1[] = new Student[Student];
		
		for(int i=0; i<stu1.length; i++) {
			System.out.println("이름,국어,영어,수학 점수입력");
			String name =s.next();
			int kor = s.nextInt();
			int eng = s.nextInt();
			int mat = s.nextInt();
			
			stu1[i] = new Student(name,kor,eng,mat);
			stu1[i].avg();
			stu1[i].grade();
			
		}
	}

}
